$(document).ready(generateMenu);

function generateMenu() {

}